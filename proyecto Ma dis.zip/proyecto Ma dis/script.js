/* ==========================================================================
   DISCRETE MATH HUB - LÓGICA Y FUNCIONALIDAD EN JAVASCRIPT
   ========================================================================== */

// --- 1. NAVEGACIÓN ENTRE PESTAÑAS ---
function switchTab(tabId) {
  const tabs = document.querySelectorAll('.cw-tab-content');
  tabs.forEach(tab => tab.classList.remove('active'));

  const navLinks = document.querySelectorAll('.cw-nav-link');
  navLinks.forEach(link => link.classList.remove('active'));

  const targetTab = document.getElementById('tab-' + tabId);
  if (targetTab) {
    targetTab.classList.add('active');
  }

  const activeBtn = Array.from(navLinks).find(btn => 
    btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(tabId)
  );
  if (activeBtn) {
    activeBtn.classList.add('active');
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// --- 2. CALCULADORA DE LÓGICA PROPOSICIONAL ---
function calcularLogica() {
  const p = document.getElementById('valP').value === 'true';
  const q = document.getElementById('valQ').value === 'true';
  const r = document.getElementById('valR').value === 'true';

  const exp1 = (!p || !q) && r;
  const exp2 = (!p) || q;
  const exp3 = ((p && !q) || !r) ? q : true;

  const resDiv = document.getElementById('resLogicaDetalle');
  resDiv.innerHTML = `
    <p><strong>1. $(\\sim p \\lor \\sim q) \\land r$:</strong> <span style="color:${exp1 ? 'green':'red'}">${exp1 ? 'Verdadero (V)' : 'Falso (F)'}</span></p>
    <p><strong>2. Condicional $p \\rightarrow q$:</strong> <span style="color:${exp2 ? 'green':'red'}">${exp2 ? 'Verdadero (V)' : 'Falso (F)'}</span></p>
    <p><strong>3. Expresión $[(p \\land \\sim q) \\lor \\sim r] \\rightarrow q$:</strong> <span style="color:${exp3 ? 'green':'red'}">${exp3 ? 'Verdadero (V)' : 'Falso (F)'}</span></p>
  `;

  document.getElementById('logicaResultados').style.display = 'block';

  if (window.renderMathInElement) {
    renderMathInElement(resDiv);
  }
}

// --- 3. CONVERSOR AUTOMÁTICO DE SISTEMAS DE NUMERACIÓN ---
function convertirDesdeDecimal() {
  const val = document.getElementById('inputDecimal').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 10);
  if (isNaN(num)) return;

  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeBinario() {
  const val = document.getElementById('inputBinario').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 2);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeHexa() {
  const val = document.getElementById('inputHexa').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 16);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeOctal() {
  const val = document.getElementById('inputOctal').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 8);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
}

function limpiarCamposConversor() {
  document.getElementById('inputDecimal').value = '';
  document.getElementById('inputBinario').value = '';
  document.getElementById('inputHexa').value = '';
  document.getElementById('inputOctal').value = '';
}

// --- 4. TEORÍA DE CONJUNTOS ---
function procesarConjuntos() {
  const strA = document.getElementById('conjAInput').value;
  const strB = document.getElementById('conjBInput').value;

  const setA = new Set(strA.split(',').map(s => s.trim()).filter(s => s.length > 0));
  const setB = new Set(strB.split(',').map(s => s.trim()).filter(s => s.length > 0));

  const union = new Set([...setA, ...setB]);
  const interseccion = new Set([...setA].filter(x => setB.has(x)));
  const diferencia = new Set([...setA].filter(x => !setB.has(x)));
  const difSimetrica = new Set([...diferencia, ...[...setB].filter(x => !setA.has(x))]);

  document.getElementById('resUnion').innerText = `{ ${Array.from(union).join(', ')} }`;
  document.getElementById('resInterseccion').innerText = `{ ${Array.from(interseccion).join(', ')} }`;
  document.getElementById('resDiferencia').innerText = `{ ${Array.from(diferencia).join(', ')} }`;
  document.getElementById('resDifSimetrica').innerText = `{ ${Array.from(difSimetrica).join(', ')} }`;

  document.getElementById('conjuntResultados').style.display = 'block';
}

// --- 5. COMBINATORIA ---
function factorial(n) {
  if (n < 0) return 0;
  if (n === 0 || n === 1) return 1;
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function calcularCombinatoria() {
  const n = parseInt(document.getElementById('inputN').value) || 0;
  const r = parseInt(document.getElementById('inputR').value) || 0;

  if (r > n) {
    alert('El valor de r no puede ser mayor que n.');
    return;
  }

  const factN = factorial(n);
  const nPr = factorial(n) / factorial(n - r);
  const nCr = factorial(n) / (factorial(r) * factorial(n - r));

  document.getElementById('resFactN').innerText = `${n}! = ${factN}`;
  document.getElementById('resNPr').innerText = `P(${n}, ${r}) = ${nPr}`;
  document.getElementById('resNCr').innerText = `C(${n}, ${r}) = ${nCr}`;

  document.getElementById('combResultados').style.display = 'block';
}

// --- 6. CANVAS DE GRAFOS ---
let nodosGrafo = [];

document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('grafoCanvas');
  if (canvas) {
    canvas.addEventListener('click', function(e) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      nodosGrafo.push({ x, y, id: String.fromCharCode(65 + nodosGrafo.length) });
      dibujarGrafo();
    });
  }
});

function dibujarGrafo() {
  const canvas = document.getElementById('grafoCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#8B5CF6';
  ctx.lineWidth = 2;
  for (let i = 0; i < nodosGrafo.length - 1; i++) {
    ctx.beginPath();
    ctx.moveTo(nodosGrafo[i].x, nodosGrafo[i].y);
    ctx.lineTo(nodosGrafo[i+1].x, nodosGrafo[i+1].y);
    ctx.stroke();
  }

  nodosGrafo.forEach(nodo => {
    ctx.beginPath();
    ctx.arc(nodo.x, nodo.y, 16, 0, 2 * Math.PI);
    ctx.fillStyle = '#6B1D39';
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 12px Inter';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(nodo.id, nodo.x, nodo.y);
  });
}

function limpiarGrafo() {
  nodosGrafo = [];
  dibujarGrafo();
  document.getElementById('matrizOutput').style.display = 'none';
}

function generarMatrizAdyacencia() {
  const n = nodosGrafo.length;
  if (n === 0) {
    alert('Añade primero nodos haciendo clic en el cuadro.');
    return;
  }

  let html = '<h4>Matriz de Adyacencia:</h4><table class="cw-table"><thead><tr><th></th>';
  nodosGrafo.forEach(nodo => html += `<th>${nodo.id}</th>`);
  html += '</tr></thead><tbody>';

  for (let i = 0; i < n; i++) {
    html += `<tr><th>${nodosGrafo[i].id}</th>`;
    for (let j = 0; j < n; j++) {
      const conectado = Math.abs(i - j) === 1 ? 1 : 0;
      html += `<td>${conectado}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';

  const out = document.getElementById('matrizOutput');
  out.innerHTML = html;
  out.style.display = 'block';
}

// --- 7. SIMULADOR DE COMPUERTAS LÓGICAS ---
function simularCompuerta() {
  const a = parseInt(document.getElementById('gateA').value);
  const b = parseInt(document.getElementById('gateB').value);
  const type = document.getElementById('gateType').value;

  let res = 0;
  switch (type) {
    case 'AND': res = (a && b) ? 1 : 0; break;
    case 'OR':  res = (a || b) ? 1 : 0; break;
    case 'XOR': res = (a !== b) ? 1 : 0; break;
    case 'NAND':res = !(a && b) ? 1 : 0; break;
    case 'NOR': res = !(a || b) ? 1 : 0; break;
  }

  document.getElementById('gateResultValue').innerText = `Salida (${type}): ${res}`;
  document.getElementById('gateResult').style.display = 'block';
}

