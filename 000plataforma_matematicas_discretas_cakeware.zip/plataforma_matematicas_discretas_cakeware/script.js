/* ==========================================================================
   DISCRETE MATH HUB - LÓGICA Y FUNCIONALIDAD COMPLETA + RED DINÁMICA
   ========================================================================== */

// --- 1. NAVEGACIÓN ENTRE PESTAÑAS ---
function switchTab(tabId) {
  const tabs = document.querySelectorAll('.cw-tab-content');
  tabs.forEach(tab => tab.classList.remove('active'));

  const navLinks = document.querySelectorAll('.cw-nav-link');
  navLinks.forEach(link => link.classList.remove('active'));

  const targetTab = document.getElementById('tab-' + tabId);
  if (targetTab) {
    targetTab.classList.add('active');
  }

  const activeBtn = Array.from(navLinks).find(btn => 
    btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(tabId)
  );
  if (activeBtn) {
    activeBtn.classList.add('active');
  }

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// --- 2. GESTIÓN DE RED DINÁMICA DE SUCURSALES ---
let redGrafo = {
  nodes: ['A', 'B', 'C', 'D', 'E'],
  edges: [
    { u: 'A', v: 'B', w: 4 },
    { u: 'A', v: 'C', w: 2 },
    { u: 'B', v: 'C', w: 1 },
    { u: 'B', v: 'D', w: 5 },
    { u: 'C', v: 'D', w: 8 },
    { u: 'C', v: 'E', w: 10 },
    { u: 'D', v: 'E', w: 2 }
  ]
};

function agregarNodoDinamico() {
  const val = document.getElementById('nuevoNodoInput').value.trim().toUpperCase();
  if (!val) return alert('Ingrese un nombre o etiqueta para la sucursal.');
  if (redGrafo.nodes.includes(val)) return alert('La sucursal ya existe en la red.');

  redGrafo.nodes.push(val);
  document.getElementById('nuevoNodoInput').value = '';
  actualizarDesplegablesYLista();
}

function agregarAristaDinamica() {
  const u = document.getElementById('origenAristaSelect').value;
  const v = document.getElementById('destinoAristaSelect').value;
  const w = parseFloat(document.getElementById('pesoAristaInput').value);

  if (u === v) return alert('El origen y destino deben ser sucursales distintas.');
  if (isNaN(w) || w <= 0) return alert('Ingrese una distancia/tiempo válido mayor a 0.');

  redGrafo.edges.push({ u, v, w });
  document.getElementById('pesoAristaInput').value = '';
  actualizarDesplegablesYLista();
}

function reiniciarRedPredefinida() {
  redGrafo = {
    nodes: ['A', 'B', 'C', 'D', 'E'],
    edges: [
      { u: 'A', v: 'B', w: 4 },
      { u: 'A', v: 'C', w: 2 },
      { u: 'B', v: 'C', w: 1 },
      { u: 'B', v: 'D', w: 5 },
      { u: 'C', v: 'D', w: 8 },
      { u: 'C', v: 'E', w: 10 },
      { u: 'D', v: 'E', w: 2 }
    ]
  };
  actualizarDesplegablesYLista();
}

function actualizarDesplegablesYLista() {
  const selOrig = document.getElementById('origenAristaSelect');
  const selDest = document.getElementById('destinoAristaSelect');
  const selDijkStart = document.getElementById('dijkstraStart');
  const selDijkEnd = document.getElementById('dijkstraEnd');

  const optionsHTML = redGrafo.nodes.map(n => `<option value="${n}">Sucursal ${n}</option>`).join('');

  if (selOrig) selOrig.innerHTML = optionsHTML;
  if (selDest) selDest.innerHTML = optionsHTML;
  if (selDijkStart) selDijkStart.innerHTML = optionsHTML;
  if (selDijkEnd) selDijkEnd.innerHTML = optionsHTML;

  document.getElementById('nodosListaText').innerText = redGrafo.nodes.join(', ');
  document.getElementById('aristasListaText').innerText = redGrafo.edges.map(e => `(${e.u}-${e.v}:${e.w})`).join(', ');
}

document.addEventListener('DOMContentLoaded', () => {
  actualizarDesplegablesYLista();
});

// --- 3. CALCULADORA DE LÓGICA PROPOSICIONAL ---
function calcularLogica() {
  const p = document.getElementById('valP').value === 'true';
  const q = document.getElementById('valQ').value === 'true';
  const r = document.getElementById('valR').value === 'true';

  const exp1 = (!p || !q) && r;
  const exp2 = (!p) || q;
  const exp3 = ((p && !q) || !r) ? q : true;

  const resDiv = document.getElementById('resLogicaDetalle');
  resDiv.innerHTML = `
    <p style="margin-bottom:8px;"><strong>1. (&not;p &or; &not;q) &and; r:</strong> 
      <span style="color:${exp1 ? '#16a34a':'#dc2626'}; font-weight:600;">${exp1 ? 'Verdadero (V)' : 'Falso (F)'}</span>
    </p>
    <p style="margin-bottom:8px;"><strong>2. Condicional p &rarr; q:</strong> 
      <span style="color:${exp2 ? '#16a34a':'#dc2626'}; font-weight:600;">${exp2 ? 'Verdadero (V)' : 'Falso (F)'}</span>
    </p>
    <p style="margin-bottom:8px;"><strong>3. Expresión [(p &and; &not;q) &or; &not;r] &rarr; q:</strong> 
      <span style="color:${exp3 ? '#16a34a':'#dc2626'}; font-weight:600;">${exp3 ? 'Verdadero (V)' : 'Falso (F)'}</span>
    </p>
  `;

  document.getElementById('logicaResultados').style.display = 'block';
}

// --- 4. TEORÍA DE CONJUNTOS ---
function procesarConjuntos() {
  const strA = document.getElementById('conjAInput').value;
  const strB = document.getElementById('conjBInput').value;

  const setA = new Set(strA.split(',').map(s => s.trim()).filter(s => s.length > 0));
  const setB = new Set(strB.split(',').map(s => s.trim()).filter(s => s.length > 0));

  const union = new Set([...setA, ...setB]);
  const interseccion = new Set([...setA].filter(x => setB.has(x)));
  const diferencia = new Set([...setA].filter(x => !setB.has(x)));
  const difSimetrica = new Set([...diferencia, ...[...setB].filter(x => !setA.has(x))]);

  document.getElementById('resUnion').innerText = `{ ${Array.from(union).join(', ')} }`;
  document.getElementById('resInterseccion').innerText = `{ ${Array.from(interseccion).join(', ')} }`;
  document.getElementById('resDiferencia').innerText = `{ ${Array.from(diferencia).join(', ')} }`;
  document.getElementById('resDifSimetrica').innerText = `{ ${Array.from(difSimetrica).join(', ')} }`;

  document.getElementById('conjuntResultados').style.display = 'block';
}

// --- 5. CONVERSOR AUTOMÁTICO DE SISTEMAS DE NUMERACIÓN ---
function convertirDesdeDecimal() {
  const val = document.getElementById('inputDecimal').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 10);
  if (isNaN(num)) return;

  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeBinario() {
  const val = document.getElementById('inputBinario').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 2);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeHexa() {
  const val = document.getElementById('inputHexa').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 16);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputOctal').value = num.toString(8);
}

function convertirDesdeOctal() {
  const val = document.getElementById('inputOctal').value.trim();
  if (val === '') { limpiarCamposConversor(); return; }

  const num = parseInt(val, 8);
  if (isNaN(num)) return;

  document.getElementById('inputDecimal').value = num.toString(10);
  document.getElementById('inputBinario').value = num.toString(2);
  document.getElementById('inputHexa').value = num.toString(16).toUpperCase();
}

function limpiarCamposConversor() {
  document.getElementById('inputDecimal').value = '';
  document.getElementById('inputBinario').value = '';
  document.getElementById('inputHexa').value = '';
  document.getElementById('inputOctal').value = '';
}

// --- 6. COMBINATORIA ---
function factorial(n) {
  if (n < 0) return 0;
  if (n === 0 || n === 1) return 1;
  let res = 1;
  for (let i = 2; i <= n; i++) res *= i;
  return res;
}

function calcularCombinatoria() {
  const n = parseInt(document.getElementById('inputN').value) || 0;
  const r = parseInt(document.getElementById('inputR').value) || 0;

  if (r > n) {
    alert('El valor de r no puede ser mayor que n.');
    return;
  }

  const factN = factorial(n);
  const nPr = factorial(n) / factorial(n - r);
  const nCr = factorial(n) / (factorial(r) * factorial(n - r));

  document.getElementById('resFactN').innerText = `${n}! = ${factN}`;
  document.getElementById('resNPr').innerText = `P(${n}, ${r}) = ${nPr}`;
  document.getElementById('resNCr').innerText = `C(${n}, ${r}) = ${nCr}`;

  document.getElementById('combResultados').style.display = 'block';
}

// --- 7. CANVAS DE GRAFOS DIBUJADOS ---
let nodosGrafo = [];

document.addEventListener('DOMContentLoaded', () => {
  const canvas = document.getElementById('grafoCanvas');
  if (canvas) {
    canvas.addEventListener('click', function(e) {
      const rect = canvas.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;

      nodosGrafo.push({ x, y, id: String.fromCharCode(65 + nodosGrafo.length) });
      dibujarGrafo();
    });
  }
});

function dibujarGrafo() {
  const canvas = document.getElementById('grafoCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  ctx.strokeStyle = '#8B5CF6';
  ctx.lineWidth = 2;
  for (let i = 0; i < nodosGrafo.length - 1; i++) {
    ctx.beginPath();
    ctx.moveTo(nodosGrafo[i].x, nodosGrafo[i].y);
    ctx.lineTo(nodosGrafo[i+1].x, nodosGrafo[i+1].y);
    ctx.stroke();
  }

  nodosGrafo.forEach(nodo => {
    ctx.beginPath();
    ctx.arc(nodo.x, nodo.y, 16, 0, 2 * Math.PI);
    ctx.fillStyle = '#6B1D39';
    ctx.fill();
    ctx.strokeStyle = '#FFFFFF';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 12px Inter';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(nodo.id, nodo.x, nodo.y);
  });
}

function limpiarGrafo() {
  nodosGrafo = [];
  dibujarGrafo();
  document.getElementById('matrizOutput').style.display = 'none';
}

function generarMatrizAdyacencia() {
  const n = nodosGrafo.length;
  if (n === 0) {
    alert('Añade primero nodos haciendo clic en el cuadro.');
    return;
  }

  let html = '<h4>Matriz de Adyacencia:</h4><table class="cw-table"><thead><tr><th></th>';
  nodosGrafo.forEach(nodo => html += `<th>${nodo.id}</th>`);
  html += '</tr></thead><tbody>';

  for (let i = 0; i < n; i++) {
    html += `<tr><th>${nodosGrafo[i].id}</th>`;
    for (let j = 0; j < n; j++) {
      const conectado = Math.abs(i - j) === 1 ? 1 : 0;
      html += `<td>${conectado}</td>`;
    }
    html += '</tr>';
  }
  html += '</tbody></table>';

  const out = document.getElementById('matrizOutput');
  out.innerHTML = html;
  out.style.display = 'block';
}

// --- 8. ALGORITMOS DE GRAFOS (DIJKSTRA, KRUSKAL, EULER) SOBRE LA RED ACTUAL ---
function ejecutarDijkstra() {
  const start = document.getElementById('dijkstraStart').value;
  const end = document.getElementById('dijkstraEnd').value;

  if (!start || !end) return alert('Defina al menos dos sucursales en la red.');
  if (start === end) return alert('Seleccione un origen y destino diferentes.');

  let dist = {};
  let prev = {};
  let unvisited = new Set(redGrafo.nodes);

  redGrafo.nodes.forEach(n => {
    dist[n] = Infinity;
    prev[n] = null;
  });
  dist[start] = 0;

  while (unvisited.size > 0) {
    let current = null;
    let minDist = Infinity;
    unvisited.forEach(n => {
      if (dist[n] < minDist) {
        minDist = dist[n];
        current = n;
      }
    });

    if (!current || current === end) break;
    unvisited.delete(current);

    redGrafo.edges.forEach(e => {
      let neighbor = null;
      if (e.u === current) neighbor = e.v;
      else if (e.v === current) neighbor = e.u;

      if (neighbor && unvisited.has(neighbor)) {
        let alt = dist[current] + e.w;
        if (alt < dist[neighbor]) {
          dist[neighbor] = alt;
          prev[neighbor] = current;
        }
      }
    });
  }

  if (dist[end] === Infinity) {
    const out = document.getElementById('grafoDetalleOutput');
    out.innerHTML = `<p style="color:#dc2626;"><strong>No existe una ruta conectada</strong> entre la sucursal ${start} y la sucursal ${end}.</p>`;
    document.getElementById('grafoResultados').style.display = 'block';
    return;
  }

  let path = [];
  let curr = end;
  while (curr) {
    path.unshift(curr);
    curr = prev[curr];
  }

  const out = document.getElementById('grafoDetalleOutput');
  out.innerHTML = `
    <h4 style="color:var(--primary); margin:0 0 10px 0;">Resultado del Algoritmo de Dijkstra:</h4>
    <p><strong>Ruta Óptima de Entrega:</strong> ${path.join(' &rarr; ')}</p>
    <p><strong>Costo Total (Distancia/Tiempo):</strong> <span style="color:#16a34a; font-weight:bold;">${dist[end]} unidades</span></p>
  `;
  document.getElementById('grafoResultados').style.display = 'block';
}

function ejecutarKruskal() {
  if (redGrafo.nodes.length === 0) return alert('No hay sucursales en la red.');

  let edgesCopy = [...redGrafo.edges].sort((a, b) => a.w - b.w);
  let parent = {};
  redGrafo.nodes.forEach(n => parent[n] = n);

  function find(i) {
    if (parent[i] === i) return i;
    return find(parent[i]);
  }

  function union(i, j) {
    let rootI = find(i);
    let rootJ = find(j);
    parent[rootI] = rootJ;
  }

  let mst = [];
  let totalCost = 0;

  edgesCopy.forEach(e => {
    let rootU = find(e.u);
    let rootV = find(e.v);
    if (rootU !== rootV) {
      mst.push(e);
      totalCost += e.w;
      union(e.u, e.v);
    }
  });

  const out = document.getElementById('grafoDetalleOutput');
  let mstList = mst.map(e => `Sucursal ${e.u} &harr; Sucursal ${e.v} (Peso: ${e.w})`).join('<br>');
  out.innerHTML = `
    <h4 style="color:var(--primary); margin:0 0 10px 0;">Árbol de Expansión Mínima (Kruskal MST):</h4>
    <p><strong>Conexiones Seleccionadas para la Red:</strong><br>${mstList || 'Sin conexiones'}</p>
    <p><strong>Costo Mínimo Total de Tuberías/Cables:</strong> <span style="color:#16a34a; font-weight:bold;">${totalCost} unidades</span></p>
  `;
  document.getElementById('grafoResultados').style.display = 'block';
}

function verificarEuler() {
  const str = document.getElementById('gradosVertices').value;
  const grados = str.split(',').map(s => parseInt(s.trim())).filter(n => !isNaN(n));

  if (grados.length === 0) {
    alert('Ingresa al menos 2 grados numéricos válidos.');
    return;
  }

  let impares = grados.filter(g => g % 2 !== 0).length;
  let txt = '';
  if (impares === 0) {
    txt = '<strong style="color:#16a34a;">¡Existe un Circuito Euleriano!</strong> Todos los vértices tienen grado par. El vehículo de inspección/basura puede empezar y terminar en la misma sucursal sin repetir calles.';
  } else if (impares === 2) {
    txt = '<strong style="color:#eab308;">¡Existe un Camino Euleriano!</strong> Exactamente 2 vértices tienen grado impar. Es posible hacer el recorrido completo pero iniciando en uno de los vértices impares y terminando en el otro.';
  } else {
    txt = '<strong style="color:#dc2626;">No existe Circuito ni Camino Euleriano.</strong> Hay ' + impares + ' vértices de grado impar.';
  }

  document.getElementById('eulerOutput').innerHTML = txt;
  document.getElementById('eulerResultados').style.display = 'block';
}

// --- 9. SIMULADOR RSA Y LUHN ---
let rsaGlobal = { n: 0, e: 0, d: 0 };

function gcd(a, b) {
  while (b) {
    let t = b;
    b = a % b;
    a = t;
  }
  return a;
}

function modInverse(e, phi) {
  let m0 = phi, y = 0, x = 1;
  if (phi === 1) return 0;
  while (e > 1) {
    let q = Math.floor(e / phi);
    let t = phi;
    phi = e % phi; e = t;
    t = y;
    y = x - q * y;
    x = t;
  }
  if (x < 0) x += m0;
  return x;
}

function powerMod(base, exp, mod) {
  let res = 1;
  base = base % mod;
  while (exp > 0) {
    if (exp % 2 === 1) res = (res * base) % mod;
    exp = Math.floor(exp / 2);
    base = (base * base) % mod;
  }
  return res;
}

function generarLlavesRSA() {
  const p = parseInt(document.getElementById('rsaP').value);
  const q = parseInt(document.getElementById('rsaQ').value);

  if (!p || !q || p <= 1 || q <= 1) {
    alert('Por favor ingrese dos números primos válidos.');
    return;
  }

  const n = p * q;
  const phi = (p - 1) * (q - 1);
  let e = 17;
  while (e < phi && gcd(e, phi) !== 1) {
    e++;
  }
  const d = modInverse(e, phi);

  rsaGlobal = { n, e, d };

  document.getElementById('rsaN').innerText = n;
  document.getElementById('rsaPhi').innerText = phi;
  document.getElementById('rsaPubKey').innerText = `(${e}, ${n})`;
  document.getElementById('rsaPrivKey').innerText = `(${d}, ${n})`;

  document.getElementById('rsaKeysArea').style.display = 'block';
}

function cifrarRSA() {
  const msg = parseInt(document.getElementById('rsaMsg').value);
  if (!rsaGlobal.n) {
    alert('Primero genera las claves RSA.');
    return;
  }
  if (msg >= rsaGlobal.n) {
    alert('El mensaje debe ser menor que n (' + rsaGlobal.n + ').');
    return;
  }

  const cipher = powerMod(msg, rsaGlobal.e, rsaGlobal.n);
  document.getElementById('rsaOutText').innerHTML = `Mensaje Original <strong>${msg}</strong> &rarr; Cifrado: <strong style="color:#6B1D39;">${cipher}</strong>`;
  document.getElementById('rsaResultArea').style.display = 'block';
}

function descifrarRSA() {
  const msg = parseInt(document.getElementById('rsaMsg').value);
  if (!rsaGlobal.n) {
    alert('Primero genera las claves RSA.');
    return;
  }
  const cipher = powerMod(msg, rsaGlobal.e, rsaGlobal.n);
  const decrypted = powerMod(cipher, rsaGlobal.d, rsaGlobal.n);
  
  document.getElementById('rsaOutText').innerHTML = `Mensaje Cifrado <strong>${cipher}</strong> &rarr; Descifrado: <strong style="color:#16a34a;">${decrypted}</strong>`;
  document.getElementById('rsaResultArea').style.display = 'block';
}

function validarLuhn() {
  const val = document.getElementById('luhnInput').value.replace(/\D/g, '');
  if (val.length === 0) {
    alert('Ingrese un número para validar.');
    return;
  }

  let sum = 0;
  let shouldDouble = false;
  for (let i = val.length - 1; i >= 0; i--) {
    let digit = parseInt(val.charAt(i));
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }

  const isValid = (sum % 10 === 0);
  document.getElementById('luhnOutputText').innerHTML = isValid
    ? `<strong style="color:#16a34a;">¡Código VÁLIDO!</strong> Cumple con el checksum de Luhn (Mod 10 = 0).`
    : `<strong style="color:#dc2626;">Código INVÁLIDO.</strong> Se detectó error de transmisión.`;
  document.getElementById('luhnResult').style.display = 'block';
}

// --- 10. HUFFMAN Y SISTEMA EXPERTO ---
function procesarHuffman() {
  const text = document.getElementById('huffmanText').value;
  if (!text) return;

  let freq = {};
  for (let char of text) {
    freq[char] = (freq[char] || 0) + 1;
  }

  let chars = Object.keys(freq).sort((a,b) => freq[b] - freq[a]);
  let codes = {};
  chars.forEach((ch, idx) => {
    codes[ch] = (idx === 0) ? '0' : '1'.repeat(idx);
  });

  let originalBits = text.length * 8;
  let compressedBits = 0;
  for (let char of text) {
    compressedBits += codes[char].length;
  }
  let saving = (((originalBits - compressedBits) / originalBits) * 100).toFixed(1);

  document.getElementById('huffOriginalBits').innerText = originalBits;
  document.getElementById('huffCompressedBits').innerText = compressedBits;
  document.getElementById('huffSaving').innerText = saving;

  let tableHtml = '<table class="cw-table"><thead><tr><th>Carácter</th><th>Frecuencia</th><th>Código Huffman</th></tr></thead><tbody>';
  chars.forEach(ch => {
    tableHtml += `<tr><td>'${ch === ' ' ? 'Espacio' : ch}'</td><td>${freq[ch]}</td><td><code>${codes[ch]}</code></td></tr>`;
  });
  tableHtml += '</tbody></table>';

  document.getElementById('huffmanCodesTable').innerHTML = tableHtml;
  document.getElementById('huffmanResult').style.display = 'block';
}

const arbolDiagnostico = {
  pregunta: '¿El equipo enciende al presionar el botón de encendido?',
  si: {
    pregunta: '¿Muestra imagen en la pantalla?',
    si: { diagnosis: 'Fallo de Software / Sistema Operativo corrupto. Iniciar recuperación.' },
    no: { diagnosis: 'Fallo de Memoria RAM o Tarjeta Gráfica. Revisar contactos.' }
  },
  no: {
    pregunta: '¿El LED del cargador/fuente de poder está encendido?',
    si: { diagnosis: 'Fallo en la Placa Madre / Botón de Encendido averiado.' },
    no: { diagnosis: 'Fallo de Fuente de Alimentación / Cable defectuoso.' }
  }
};

let nodoActualExperto = arbolDiagnostico;

function responderExperto(respuesta) {
  if (respuesta) {
    nodoActualExperto = nodoActualExperto.si;
  } else {
    nodoActualExperto = nodoActualExperto.no;
  }

  if (nodoActualExperto.diagnosis) {
    document.getElementById('expertTreeStep').style.display = 'none';
    document.getElementById('expertDiagText').innerText = 'Diagnóstico Sugerido: ' + nodoActualExperto.diagnosis;
    document.getElementById('expertDiagnosis').style.display = 'block';
  } else {
    document.getElementById('expertQuestion').innerText = nodoActualExperto.pregunta;
  }
}

function reiniciarExperto() {
  nodoActualExperto = arbolDiagnostico;
  document.getElementById('expertQuestion').innerText = nodoActualExperto.pregunta;
  document.getElementById('expertTreeStep').style.display = 'block';
  document.getElementById('expertDiagnosis').style.display = 'none';
}

// --- 11. ALARMA DOMÉSTICA ---
function evaluarAlarma() {
  const a = parseInt(document.getElementById('sensorA').value);
  const b = parseInt(document.getElementById('sensorB').value);
  const c = parseInt(document.getElementById('sensorC').value);
  const d = parseInt(document.getElementById('sensorD').value);

  const activada = d && (a || b || c);
  const el = document.getElementById('alarmaState');

  if (activada) {
    el.innerText = '🚨 ALARMA ACTIVADA: ¡INTRUSIÓN DETECTADA!';
    el.style.color = '#dc2626';
  } else {
    el.innerText = '🛡️ SISTEMA EN REPOSO: Sin novedad';
    el.style.color = '#16a34a';
  }

  document.getElementById('alarmaResult').style.display = 'block';
}

// --- 12. COMPUERTAS BOOLEANAS ---
function simularCompuerta() {
  const a = parseInt(document.getElementById('gateA').value);
  const b = parseInt(document.getElementById('gateB').value);
  const type = document.getElementById('gateType').value;

  let res = 0;
  switch (type) {
    case 'AND': res = (a && b) ? 1 : 0; break;
    case 'OR':  res = (a || b) ? 1 : 0; break;
    case 'XOR': res = (a !== b) ? 1 : 0; break;
    case 'NAND':res = !(a && b) ? 1 : 0; break;
    case 'NOR': res = !(a || b) ? 1 : 0; break;
  }

  document.getElementById('gateResultValue').innerText = `Salida (${type}): ${res}`;
  document.getElementById('gateResult').style.display = 'block';
}