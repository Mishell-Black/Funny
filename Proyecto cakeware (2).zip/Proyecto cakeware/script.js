 
 // 1. Configuración de fechas y estado del pedido
  const hoy = new Date();
  const fechaMinima = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate() + 2);
  let mesActual = hoy.getMonth();
  let anoActual = hoy.getFullYear();
  let fechaSeleccionada = null;
  let horaSeleccionada = null;
  
  const fechasLlenas = ["2026-10-05", "2026-10-12", "2026-10-18"];
  const horariosBase = [
    "09:00 a. m.", "10:00 a. m.", "11:00 a. m.",
    "01:00 p. m.", "02:00 p. m.", "03:00 p. m.",
    "04:00 p. m.", "05:00 p. m.", "06:00 p. m."
  ];
  const mesesNombres = [
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
  ];

  // Objeto global para almacenar la selección completa
  const order = {
    tamano: 'Pendiente',
    tamanoPrice: 0,
    masa: 'Pendiente',
    relleno: 'Pendiente',
    decoracion: 'Pendiente',
    mensaje: 'Ninguno',
    notas: 'Sin notas'
  };

  // 2. Lógica del Calendario
  function renderizarCalendario() {
    const titleEl = document.getElementById("calTitle");
    const gridEl = document.getElementById("calDaysGrid");
    const btnPrev = document.getElementById("btnPrev");
    const btnNext = document.getElementById("btnNext");
    if (!titleEl || !gridEl) return;

    titleEl.textContent = `${mesesNombres[mesActual]} ${anoActual}`;

    const esMesInicial = (anoActual === hoy.getFullYear() && mesActual === hoy.getMonth());
    const mesLimite = new Date(hoy.getFullYear(), hoy.getMonth() + 2, 1);
    const esMesMaximo = (anoActual === mesLimite.getFullYear() && mesActual === mesLimite.getMonth());
    
    if (btnPrev) btnPrev.disabled = esMesInicial;
    if (btnNext) btnNext.disabled = esMesMaximo;
    gridEl.innerHTML = "";

    const primerDiaSemana = new Date(anoActual, mesActual, 1).getDay();
    const totalDiasMes = new Date(anoActual, mesActual + 1, 0).getDate();

    for (let i = 0; i < primerDiaSemana; i++) {
      const empty = document.createElement("div");
      empty.className = "cal-day-cell empty";
      gridEl.appendChild(empty);
    }

    for (let dia = 1; dia <= totalDiasMes; dia++) {
      const fechaIterada = new Date(anoActual, mesActual, dia);
      const mesFormateado = String(mesActual + 1).padStart(2, '0');
      const diaFormateado = String(dia).padStart(2, '0');
      const fechaISO = `${anoActual}-${mesFormateado}-${diaFormateado}`;
      
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "cal-day-cell";
      btn.textContent = dia;

      if (fechaIterada < fechaMinima) {
        btn.classList.add("disabled"); 
        btn.disabled = true;
      } else if (fechasLlenas.includes(fechaISO)) {
        btn.classList.add("busy"); 
        btn.disabled = true;
      } else {
        btn.classList.add("free");
        if (fechaSeleccionada === fechaISO) btn.classList.add("selected");
        btn.onclick = () => seleccionarFecha(fechaISO, dia, btn);
      }
      gridEl.appendChild(btn);
    }
  }

  function seleccionarFecha(fechaISO, dia, elementoBtn) {
    fechaSeleccionada = fechaISO;
    horaSeleccionada = null;
    document.querySelectorAll(".cal-day-cell").forEach(b => b.classList.remove("selected"));
    elementoBtn.classList.add("selected");
    
    const sub = document.getElementById("timeSubtitle");
    if (sub) sub.textContent = `Horarios disponibles para el ${dia} de ${mesesNombres[mesActual]}:`;
    
    renderizarHorarios();
    validarFormulario();
  }

  function renderizarHorarios() {
    const timeGrid = document.getElementById("timeGrid");
    if (!timeGrid) return;
    timeGrid.innerHTML = "";

    horariosBase.forEach(hora => {
      const btnHora = document.createElement("button");
      btnHora.type = "button";
      btnHora.className = "time-btn";
      btnHora.textContent = hora;
      if (horaSeleccionada === hora) btnHora.classList.add("selected");
      
      btnHora.onclick = () => {
        horaSeleccionada = hora;
        document.querySelectorAll(".time-btn").forEach(b => b.classList.remove("selected"));
        btnHora.classList.add("selected");
        validarFormulario();
      };
      timeGrid.appendChild(btnHora);
    });
  }

  function validarFormulario() {
    const btnContinuar = document.getElementById("btnContinuar");
    if (btnContinuar) {
      btnContinuar.disabled = !(fechaSeleccionada && horaSeleccionada);
    }
  }

  function cambiarMes(direccion) {
    mesActual += direccion;
    if (mesActual < 0) { mesActual = 11; anoActual--; }
    else if (mesActual > 11) { mesActual = 0; anoActual++; }
    renderizarCalendario();
  }

  function pagarYApartar() {
    alert(`¡Tu pedido ha sido agendado con éxito!\n\nTe esperamos el ${fechaSeleccionada} a las ${horaSeleccionada} para recoger tu CakeWare.`);
    window.location.href = "mis_pedidos.html"; 
  }

  // 3. Navegación entre Pasos
  function goTo(stepNumber) {
    document.querySelectorAll('.step').forEach(paso => paso.classList.remove('active'));
    
    const pasoDestino = document.getElementById('step' + stepNumber);
    if (pasoDestino) pasoDestino.classList.add('active');

    // Actualizar barra de progreso
    document.querySelectorAll('.progress-dot').forEach((dot, index) => {
      const step = index + 1;
      if (step < stepNumber) {
        dot.classList.add('done'); dot.classList.remove('current');
      } else if (step === stepNumber) {
        dot.classList.add('current'); dot.classList.remove('done');
      } else {
        dot.classList.remove('done', 'current');
      }
    });

    document.querySelectorAll('.progress-line').forEach((line, index) => {
      if (index + 1 < stepNumber) line.classList.add('done');
      else line.classList.remove('done');
    });

    // Al llegar al Paso 7, actualizamos el resumen
    if (stepNumber === 7) {
      actualizarResumen();
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  // 4. Selección de Tarjetas
  function selectCard(boton, campo) {
    const pasoActual = boton.closest('.step');
    pasoActual.querySelectorAll('.card').forEach(c => c.classList.remove('sel-card', 'selected'));
    
    const tarjeta = boton.closest('.card');
    tarjeta.classList.add('sel-card');
    
    const titulo = tarjeta.querySelector('h2, .card__title, .card_title');
    if (titulo) {
      order[campo] = titulo.innerText.trim();
    }

    if (tarjeta.dataset.price) {
      order.tamanoPrice = parseInt(tarjeta.dataset.price, 10);
    }

    const numPaso = parseInt(pasoActual.id.replace('step', ''), 10);
    setTimeout(() => goTo(numPaso + 1), 350);
  }

  function selectRelleno(boton) {
    const pasoActual = boton.closest('.step');
    pasoActual.querySelectorAll('.relleno-card').forEach(c => c.classList.remove('sel-card', 'selected'));
    
    const tarjeta = boton.closest('.relleno-card');
    tarjeta.classList.add('sel-card');
    
    const titulo = tarjeta.querySelector('h2, .card__title, .card_title');
    if (titulo) {
      order.relleno = titulo.innerText.trim();
    }

    const numPaso = parseInt(pasoActual.id.replace('step', ''), 10);
    setTimeout(() => goTo(numPaso + 1), 350);
  }

  // 5. VALIDACIÓN OBLIGATORIA PASO 5 (Notas de decoración)
  function validarPaso5() {
    const notasInput = document.getElementById('notasInput');
    const mensajeInput = document.getElementById('mensajeInput');

    const notasTexto = notasInput ? notasInput.value.trim() : '';
    const mensajeTexto = mensajeInput ? mensajeInput.value.trim() : '';

    if (!notasTexto) {
      alert('Por favor ingresa las notas de decoración. Es un campo obligatorio para continuar.');
      if (notasInput) notasInput.focus();
      return;
    }

    // Guardar en el objeto order
    order.notas = notasTexto;
    order.mensaje = mensajeTexto || 'Ninguno';

    // Avanzar al formulario del cliente (Paso 6)
    goTo(6);
  }

  // 6. VALIDACIÓN OBLIGATORIA PASO 6 (Formulario del cliente)
  function validarPaso6() {
    const nombre = document.getElementById('nombreInput') ? document.getElementById('nombreInput').value.trim() : '';
    const apellido = document.getElementById('apellidoInput') ? document.getElementById('apellidoInput').value.trim() : '';
    const email = document.getElementById('emailInput') ? document.getElementById('emailInput').value.trim() : '';
    const telefono = document.getElementById('telefonoInput') ? document.getElementById('telefonoInput').value.trim() : '';
    const cedula = document.getElementById('cedulaInput') ? document.getElementById('cedulaInput').value.trim() : '';

    // Comprobar que absolutamente TODOS los campos estén llenos
    if (!nombre || !apellido || !email || !telefono || !cedula) {
      alert('Por favor completa todos los campos del formulario (Nombre, Apellido, Email, Teléfono y Cédula) para continuar.');
      return;
    }

    // Comprobar formato básico de correo electrónico
    if (!email.includes('@') || !email.includes('.')) {
      alert('Por favor ingresa una dirección de correo electrónico válida.');
      document.getElementById('emailInput').focus();
      return;
    }

    // Avanzar al paso final (Paso 7)
    goTo(7);
  }

  // 7. Cálculo y actualización del Resumen Final
  function actualizarResumen() {
    const elTamano = document.getElementById('resTamano');
    const elMasa = document.getElementById('resMasa');
    const elRelleno = document.getElementById('resRelleno');
    const elDeco = document.getElementById('resDeco');
    const elMensaje = document.getElementById('resMensaje');
    const elNotas = document.getElementById('resNotas');

    const elTotal = document.getElementById('resTotal');
    const elAnticipo = document.getElementById('resAnticipo');
    const elResto = document.getElementById('resResto');

    if (elTamano) elTamano.innerText = order.tamano || 'Pendiente';
    if (elMasa) elMasa.innerText = order.masa || 'Pendiente';
    if (elRelleno) elRelleno.innerText = order.relleno || 'Pendiente';
    if (elDeco) elDeco.innerText = order.decoracion || 'Pendiente';
    if (elMensaje) elMensaje.innerText = order.mensaje || 'Ninguno';
    if (elNotas) elNotas.innerText = order.notas || 'Sin notas';

    const precioTotal = order.tamanoPrice > 0 ? order.tamanoPrice : 80000;
    const abono50 = precioTotal / 2;

    if (elTotal) elTotal.innerText = '$ ' + precioTotal.toLocaleString('es-CO');
    if (elAnticipo) elAnticipo.innerText = '$ ' + abono50.toLocaleString('es-CO');
    if (elResto) elResto.innerText = '$ ' + abono50.toLocaleString('es-CO');
  }

  document.addEventListener("DOMContentLoaded", renderizarCalendario);
 
 
 
 function procesarLogin(event) {
      event.preventDefault(); // Evita recargar la página

      const user = document.getElementById('loginUser').value.trim();
      const pass = document.getElementById('loginPass').value.trim();

      // Validación simple con credenciales fijas
      if ((user === 'admin' && pass === '1234') || (user === 'cocina' && pass === '1234')) {
        // Ocultamos la tarjeta de Login
        document.getElementById('view-login').classList.remove('active');
        
        // Mostramos el Panel Completo con Pestañas
        document.getElementById('view-admin-panel').classList.add('active');

        // Actualizamos el nombre en pantalla
        const label = document.getElementById('sessionUser');
        if (label) label.textContent = user === 'admin' ? 'Administrador' : 'Equipo de Cocina';
      } else {
        alert('Usuario o contraseña incorrectos. (Usa: admin / 1234)');
      }
    }

    function cerrarSesionAdmin() {
      // Oculta el panel y vuelve a mostrar el login
      document.getElementById('view-admin-panel').classList.remove('active');
      document.getElementById('view-login').classList.add('active');
      
      document.getElementById('loginUser').value = '';
      document.getElementById('loginPass').value = '';
    }

    function switchAdminTab(tabName, btnElement) {
      // Oculta todas las pestañas
      document.querySelectorAll('.admin-tab-content').forEach(tab => {
        tab.classList.remove('active');
      });

      // Desmarca todos los botones
      document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
      });

      // Muestra la pestaña seleccionada
      const targetTab = document.getElementById('tab-' + tabName);
      if (targetTab) targetTab.classList.add('active');

      // Marca el botón seleccionado
      if (btnElement) btnElement.classList.add('active');
    }